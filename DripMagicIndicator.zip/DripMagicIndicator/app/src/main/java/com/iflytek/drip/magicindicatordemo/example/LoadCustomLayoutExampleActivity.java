package com.iflytek.drip.magicindicatordemo.example;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.iflytek.drip.magicindicator.MagicIndicator;
import com.iflytek.drip.magicindicator.ViewPagerHelper;
import com.iflytek.drip.magicindicator.buildins.commonnavigator.CommonNavigator;
import com.iflytek.drip.magicindicator.buildins.commonnavigator.CommonNavigatorAdapter;
import com.iflytek.drip.magicindicator.buildins.commonnavigator.IPagerIndicator;
import com.iflytek.drip.magicindicator.buildins.commonnavigator.IPagerTitleView;
import com.iflytek.drip.magicindicator.buildins.commonnavigator.titles.CommonPagerTitleView;
import com.iflytek.drip.magicindicator.buildins.commonnavigator.titles.badge.BadgeAnchor;
import com.iflytek.drip.magicindicator.buildins.commonnavigator.titles.badge.BadgePagerTitleView;
import com.iflytek.drip.magicindicatordemo.R;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class LoadCustomLayoutExampleActivity extends AppCompatActivity {
    private static final String[] CHANNELS = new String[]{"首页", "消息", "联系人", "更多"};
    private static final int[] mUnselectedIds={
           R.mipmap.tab_home_unselect,R.mipmap.tab_speech_unselect,
            R.mipmap.tab_contact_unselect,R.mipmap.tab_more_unselect
    };
    private static final int[] mSelectedIds={
            R.mipmap.tab_home_select,R.mipmap.tab_speech_select,
            R.mipmap.tab_contact_select,R.mipmap.tab_more_select
    };
    private List<String> mDataList = Arrays.asList(CHANNELS);
    private ExamplePagerAdapter mExamplePagerAdapter = new ExamplePagerAdapter(mDataList);

    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_custom_layout_example);
        mViewPager = (ViewPager) findViewById(R.id.view_pager);
        mViewPager.setAdapter(mExamplePagerAdapter);
        initMagicIndicator1();
    }

    private void initMagicIndicator1() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator1);
        magicIndicator.setBackgroundColor(Color.WHITE);
        final CommonNavigator commonNavigator = new CommonNavigator(this);
        commonNavigator.setAdjustMode(true);
        commonNavigator.setAdapter(new CommonNavigatorAdapter() {

            @Override
            public int getCount() {
                return mDataList.size();
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                BadgePagerTitleView badgePagerTitleView=new BadgePagerTitleView(context);
                CommonPagerTitleView  commonPagerTitleView= initLayout(context,index);
                commonNavigator.setPagerTitleViewWithMsgBadge(1,R.layout.simple_count_badge_layout,""+new Random().nextInt(120));
                badgePagerTitleView.setInnerPagerTitleView(commonPagerTitleView);
                badgePagerTitleView.setXBadgeRule(BadgeAnchor.CONTENT_RIGHT,-40);
                badgePagerTitleView.setYBadgeRule(BadgeAnchor.CONTENT_TOP, 6);
                return badgePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                return null;
            }
        });
        magicIndicator.setNavigator(commonNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }

    private CommonPagerTitleView initLayout(Context context,final int index){
        // load custom layout
        View customLayout = LayoutInflater.from(context).inflate(R.layout.simple_pager_title_layout, null);
        final ImageView titleImg = (ImageView) customLayout.findViewById(R.id.title_img);
        final TextView titleText = (TextView) customLayout.findViewById(R.id.title_text);
        titleImg.setImageResource(mUnselectedIds[index]);
        titleText.setText(mDataList.get(index));
        CommonPagerTitleView commonPagerTitleView=new CommonPagerTitleView(context) {
            @Override
            public void onSelected(int index, int totalCount) {
                titleText.setTextColor(Color.parseColor("#00CED1"));
            }

            @Override
            public void onDeselected(int index, int totalCount) {
                titleText.setTextColor(Color.LTGRAY);
            }

            @Override
            public void onLeave(int index, int totalCount, float leavePercent, boolean leftToRight) {
                //titleImg.setScaleX(1.3f + (0.8f - 1.3f) * leavePercent);
                // titleImg.setScaleY(1.3f + (0.8f - 1.3f) * leavePercent);
                if(leavePercent>=0.8f)
                    titleImg.setImageResource(mUnselectedIds[index]);
            }

            @Override
            public void onEnter(int index, int totalCount, float enterPercent, boolean leftToRight) {
                //titleImg.setScaleX(0.8f + (1.3f - 0.8f) * enterPercent);
                //titleImg.setScaleY(0.8f + (1.3f - 0.8f) * enterPercent);
                if(enterPercent>=0.8f)
                    titleImg.setImageResource(mSelectedIds[index]);
            }
        };
        commonPagerTitleView.setContentView(customLayout);


//        commonPagerTitleView.setOnPagerTitleChangeListener(new CommonPagerTitleView.OnPagerTitleChangeListener() {
//
//            @Override
//            public void onSelected(int index, int totalCount) {
//                titleText.setTextColor(Color.parseColor("#00CED1"));
//            }
//
//            @Override
//            public void onDeselected(int index, int totalCount) {
//                titleText.setTextColor(Color.LTGRAY);
//            }
//
//            @Override
//            public void onLeave(int index, int totalCount, float leavePercent, boolean leftToRight) {
//                //titleImg.setScaleX(1.3f + (0.8f - 1.3f) * leavePercent);
//                // titleImg.setScaleY(1.3f + (0.8f - 1.3f) * leavePercent);
//                if(leavePercent>=0.8f)
//                    titleImg.setImageResource(mUnselectedIds[index]);
//            }
//
//            @Override
//            public void onEnter(int index, int totalCount, float enterPercent, boolean leftToRight) {
//                //titleImg.setScaleX(0.8f + (1.3f - 0.8f) * enterPercent);
//                //titleImg.setScaleY(0.8f + (1.3f - 0.8f) * enterPercent);
//                if(enterPercent>=0.8f)
//                    titleImg.setImageResource(mSelectedIds[index]);
//            }
//        });
        commonPagerTitleView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mViewPager.setCurrentItem(index);
                titleImg.setImageResource(mSelectedIds[index]);

            }
        });
        return commonPagerTitleView;
    }


}
